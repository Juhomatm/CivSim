﻿using ConsoleApplication1.CivSim.MapGenerator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CivSim
{
    class SimWorld : IWorld
    {
        public static Random globalRandom = new Random();

        private IVisibleCellManager _visibleCellManager;
        private TileInfo[,] tiles;
        private List<Population> _populations;

        public int Width { get; private set; }
        public int Height { get; private set; }

        public SimWorld(IVisibleCellManager visibleCellManager)
        {
            _visibleCellManager = visibleCellManager;
            Width = 200;
            Height = 120;
            tiles = MapGenerator.MapGenerator.getMap(Width, Height, visibleCellManager);
            _populations = new List<Population>();
        }

        public TileInfo getTileInfo(int x, int y)
        {
            return tiles[x, y];
        }

        public void Update()
        {
            if(_populations.Count == 0)
            {
                _populations.Add(new Population(50, 50, _visibleCellManager));
                _populations.Add(new Population(50, 50, _visibleCellManager));
                _populations.Add(new Population(50, 50, _visibleCellManager));
                _populations.Add(new Population(50, 50, _visibleCellManager));
                _populations.Add(new Population(40, 35, _visibleCellManager));
                _populations.Add(new Population(100, 10, _visibleCellManager));
                _populations.Add(new Population(8, 100, _visibleCellManager));
                _populations.Add(new Population(8, 100, _visibleCellManager));
                _populations.Add(new Population(8, 100, _visibleCellManager));
                _populations.Add(new Population(8, 100, _visibleCellManager));
            }
            foreach (Population population in _populations)
            {
                population.Update(this);
            }
        }
    }
}

