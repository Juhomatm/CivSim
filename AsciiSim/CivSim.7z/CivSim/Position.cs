﻿namespace CivSim
{
    public class Position
    {
    }
}