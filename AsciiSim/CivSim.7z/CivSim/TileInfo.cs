﻿namespace CivSim
{
    class TileInfo
    {
        public enum TerrainType { Land, Sea }

        private int _x;
        private int _y;
        private VisibleCell _visibleCell;
        private IVisibleCellManager _visibleCellManager;

        public TerrainType Terrain { get; private set; }

        public TileInfo(int x, int y, IVisibleCellManager visibleCellManager)
        {
            _x = x;
            _y = y;
            _visibleCellManager = visibleCellManager;
            _visibleCell = _visibleCellManager.getNewCell(new Character(SpecialCharacter.Tilde), _x, _y, RLNET.RLColor.Blue);
        }

        public void setTerrain(TerrainType terrainType)
        {
            Terrain = terrainType;
            switch (Terrain)
            {
                case TerrainType.Land:
                    _visibleCell.SetCharacter(SpecialCharacter.LandSparse);
                    _visibleCell.Color = RLNET.RLColor.Green;
                    break;
                case TerrainType.Sea:
                    _visibleCell.SetCharacter(SpecialCharacter.Tilde);
                    _visibleCell.Color = RLNET.RLColor.Blue;
                    break;
                default:
                    throw new System.ArgumentException(terrainType.ToString());
            }
        }

        public void setTerrainHeight(float height)
        {
            float shade = height + 0.2f;
            _visibleCell.Color = new RLNET.RLColor(shade, shade, shade);
            _visibleCell.BackColor = new RLNET.RLColor(0.1f, 0.1f, 0.1f);
        }
    }
}